/*
 * VictoryRoyale.cpp
 *
 *  Created on: 09 may. 2018
 *      Author: Fran Gonzalez
 */

#include "VictoryRoyale.h"

#include <cstdlib>
#include <iostream>
#include <set>
#include <string>
using namespace std;

VictoryRoyale::VictoryRoyale() {
  // Inicializar las variables necesarias para ejecutar la partida
}

VictoryRoyale::~VictoryRoyale() {
  // Liberar los recursos reservados (memoria, ficheros, etc.)
}

void VictoryRoyale::initialize() {
  // Inicializar el bot antes de jugar una partida
}

string VictoryRoyale::getName() { return "VictoryRoyale"; }

vector<Move> GenerateMoveList(const GameState &state) {
  vector<Move> moves;
  for (int i = 1; i <= 6; i++)
    if (state.getSeedsAt(state.getCurrentPlayer(), (Position)i) > 0)
      moves.push_back((Move)i);

  return moves;
}

int MaxMove(const GameState &state, Move &bestMove, int nivel);
int MinMove(const GameState &state, Move &bestMove, int nivel);

set<int> listaS;
int MaxMove(const GameState &state, Move &bestMove, int nivel) {
  // cerr << "NIVEL " << nivel << endl;
  if (state.isFinalState() || nivel == 0) {
    int semillas = state.getScore(state.getCurrentPlayer());
    if (listaS.find(semillas) == listaS.end()) {
      listaS.insert(semillas);
      cerr << "Semillas: " << semillas << endl;
    }
    return semillas;
  }
  vector<Move> moveList = GenerateMoveList(state);
  int nMoves = moveList.size();
  int v = -1000;
  for (int i = 0; i < nMoves; i++) {
    Move move = moveList[i];
    // cerr << "Movimientos: " << nMoves << endl;
    GameState tmp_state = state.simulateMove(move);
    Move opponentsBestMove;
    int Rating = MinMove(tmp_state, opponentsBestMove, nivel - 1);
    if (Rating > v) {
      /*       cerr << "Nivel: " << nivel << "\tRating: " << Rating << "\tV: "
         << v
                 << endl; */
      v = Rating;
      bestMove = move;
    }
  }
  return v;
}
int MinMove(const GameState &state, Move &bestMove, int nivel) {
  // cerr << "NIVEL " << nivel << endl;
  if (state.isFinalState() || nivel == 0) {
    int semillas = state.getScore(state.getCurrentPlayer());
    // cerr << "Semillas: " << semillas << endl;
    return semillas;
  }
  vector<Move> moveList = GenerateMoveList(state);
  int nMoves = moveList.size();
  int v = 1000;
  for (int i = 0; i < nMoves; i++) {
    Move move = moveList[i];
    GameState tmp_state = state.simulateMove(move);
    Move opponentsBestMove;
    int Rating = MaxMove(tmp_state, opponentsBestMove, nivel - 1);
    if (Rating < v) {
      v = Rating;
      bestMove = move;
    }
  }
  return v;
}

Move MiniMax(const GameState &state) {
  // Movimiento aleatorio
  srand(time(0));
  vector<Move> list = GenerateMoveList(state);
  int i = rand() % list.size();
  Move bestMove = list[i];
  int mejor = -10000;

  // cerr << "Minimax antes" << endl;
  // for (int i = 0; i < list.size(); i++) {
  GameState estado = state.simulateMove(list[i]);
  int tmp = MaxMove(state, bestMove, 6);
  if (tmp > mejor) {
    mejor = tmp;
    // bestMove = list[i];
  }
  // }
  // cerr << "Minimax dsp" << endl;

  return bestMove;
}

Move VictoryRoyale::nextMove(const vector<Move> &adversary,
                             const GameState &state) {
  Move movimiento = M_NONE;
  Player turno = state.getCurrentPlayer();
  Player rival = turno == J1 ? J2 : J1;

  // Si es el primer movimiento de la partida siempre sembramos la primera
  // casilla
  vector<Move> lista = GenerateMoveList(state);
  static bool primerTurno = true;
  if (rival == J2 and primerTurno)
    for (int i = 1; i < 7; i++)
      if (state.getSeedsAt(rival, (Position)i) != 4) primerTurno = false;

  int puntos = -10000;

  if (primerTurno)
    movimiento = (Move)1;
  else {
    // cerr << state.getCurrentPlayer() << endl;
    movimiento = MiniMax(state);
  }

  return movimiento;
}
